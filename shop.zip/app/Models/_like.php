<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class _like extends Model
{
    //
    protected $table = "_like";
    
}
