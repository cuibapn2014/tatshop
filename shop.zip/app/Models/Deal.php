<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Deal extends Model
{
    //
    protected $table = "deal";

    public $timestamps = false;
}
