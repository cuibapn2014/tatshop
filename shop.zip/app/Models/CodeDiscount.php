<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CodeDiscount extends Model
{
    //
    protected $table = "code_discount";
    public $timestamps = false;
}
