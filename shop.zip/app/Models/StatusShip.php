<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StatusShip extends Model
{
    //
    protected $table = "status_shipping";
    public $timestamps = false;
}
